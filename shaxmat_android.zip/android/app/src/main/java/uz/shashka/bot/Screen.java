package uz.shashka.bot;

/** Ekran tasvirini beruvchi manba. */
interface Screen {
    /** Eng so'nggi tasvir yoki null. */
    Frame grab();
}
