package uz.shashka.bot;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;

/** Stockfish (UCI) bilan aloqa: jarayon sifatida ishga tushiriladi. */
final class UciClient {
    private final String exe;
    private Process proc;
    private BufferedWriter out;
    private final LinkedBlockingQueue<String> q = new LinkedBlockingQueue<>();
    private int fails = 0;
    String lastInfo = "";

    UciClient(String exe) {
        this.exe = exe;
    }

    private boolean alive() {
        if (proc == null) return false;
        try {
            proc.exitValue();
            return false;
        } catch (IllegalThreadStateException e) {
            return true;
        }
    }

    private void send(String s) throws IOException {
        out.write(s + "\n");
        out.flush();
    }

    private String waitFor(String prefix, long ms) throws InterruptedException {
        long end = System.currentTimeMillis() + ms;
        while (true) {
            long left = end - System.currentTimeMillis();
            if (left <= 0) return null;
            String l = q.poll(left, TimeUnit.MILLISECONDS);
            if (l == null) return null;
            if (l.equals("EOF")) return "EOF";
            if (l.startsWith(prefix)) return l;
        }
    }

    synchronized boolean start() {
        if (alive()) return true;
        if (fails >= 3) return false;
        try {
            proc = new ProcessBuilder(exe).redirectErrorStream(true).start();
            out = new BufferedWriter(new OutputStreamWriter(proc.getOutputStream()));
            q.clear();
            final java.io.InputStream is = proc.getInputStream();
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        BufferedReader r = new BufferedReader(new InputStreamReader(is));
                        String l;
                        while ((l = r.readLine()) != null) q.add(l);
                    } catch (IOException ignored) {
                    }
                    q.add("EOF");
                }
            });
            t.setDaemon(true);
            t.start();
            send("uci");
            if (waitFor("uciok", 8000) == null) throw new IOException("uciok kelmadi");
            int cpus = Math.max(1, Math.min(4, Runtime.getRuntime().availableProcessors()));
            send("setoption name Threads value " + cpus);
            send("setoption name Hash value 128");
            send("isready");
            if (waitFor("readyok", 20000) == null) throw new IOException("readyok kelmadi");
            BotLog.log("Stockfish tayyor, oqimlar: " + cpus);
            return true;
        } catch (Exception e) {
            BotLog.log("Stockfish ishga tushmadi: " + e);
            fails++;
            kill();
            return false;
        }
    }

    synchronized void newGame() {
        if (!alive()) return;
        try {
            send("ucinewgame");
            send("isready");
            waitFor("readyok", 5000);
        } catch (Exception e) {
            kill();
        }
    }

    /** Eng yaxshi yurish ("e2e4") yoki null. */
    synchronized String best(String fen, long ms) {
        if (!start()) return null;
        try {
            q.clear();
            send("position fen " + fen);
            send("go movetime " + ms);
            long end = System.currentTimeMillis() + ms + 6000;
            while (true) {
                long left = end - System.currentTimeMillis();
                if (left <= 0) {
                    BotLog.log("Stockfish javob bermadi");
                    send("stop");
                    fails++;
                    kill();
                    return null;
                }
                String l = q.poll(left, TimeUnit.MILLISECONDS);
                if (l == null) continue;
                if (l.equals("EOF")) {
                    BotLog.log("Stockfish to'xtab qoldi");
                    fails++;
                    kill();
                    return null;
                }
                if (l.startsWith("info") && l.contains(" score ")) lastInfo = l;
                if (l.startsWith("bestmove")) {
                    String[] t = l.split("\\s+");
                    if (t.length >= 2 && !t[1].equals("(none)")) {
                        BotLog.log("Stockfish: " + t[1] + " | " + shortInfo());
                        return t[1];
                    }
                    BotLog.log("Stockfish yurish bermadi (mat yoki pat?)");
                    return null;
                }
            }
        } catch (Exception e) {
            BotLog.log("Stockfish xatosi: " + e);
            fails++;
            kill();
            return null;
        }
    }

    private String shortInfo() {
        String s = lastInfo;
        int i = s.indexOf(" depth ");
        int j = s.indexOf(" score ");
        String d = i >= 0 ? s.substring(i + 1, Math.min(s.length(), i + 10)).split(" ")[1] : "?";
        String sc = j >= 0 ? s.substring(j + 7).split(" ")[0] + " " + s.substring(j + 7).split(" ")[1] : "?";
        return "chuqurlik " + d + ", baho " + sc;
    }

    synchronized void kill() {
        try {
            if (proc != null) proc.destroy();
        } catch (Exception ignored) {
        }
        proc = null;
    }

    synchronized void close() {
        try {
            if (alive()) {
                send("quit");
                proc.waitFor(1, TimeUnit.SECONDS);
            }
        } catch (Exception ignored) {
        }
        kill();
    }
}
