package uz.shashka.bot;

/** Ekranga bosish (Android'da Accessibility xizmati orqali). */
interface Tapper {
    boolean available();

    boolean tap(float x, float y, int holdMs);

    boolean swipe(float x1, float y1, float x2, float y2, int durMs);
}
