package uz.shashka.bot;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Ekranga bosish: Accessibility xizmati (Sozlamalar > Maxsus imkoniyatlar da yoqiladi). */
public class TapService extends AccessibilityService {
    static volatile TapService inst = null;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        BotLog.log("Accessibility xizmati ulandi");
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        inst = null;
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        inst = null;
        super.onDestroy();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    boolean gesture(Path p, int dur) {
        final CountDownLatch latch = new CountDownLatch(1);
        final boolean[] ok = {false};
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, Math.max(1, dur)));
        boolean sent = dispatchGesture(b.build(), new GestureResultCallback() {
            @Override
            public void onCompleted(GestureDescription g) {
                ok[0] = true;
                latch.countDown();
            }

            @Override
            public void onCancelled(GestureDescription g) {
                latch.countDown();
            }
        }, null);
        if (!sent) return false;
        try {
            latch.await(2, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return ok[0];
    }

    /** Bot uchun Tapper. */
    static final class Impl implements Tapper {
        @Override
        public boolean available() {
            return inst != null;
        }

        @Override
        public boolean tap(float x, float y, int holdMs) {
            TapService s = inst;
            if (s == null) return false;
            Path p = new Path();
            p.moveTo(x, y);
            return s.gesture(p, holdMs);
        }

        @Override
        public boolean swipe(float x1, float y1, float x2, float y2, int durMs) {
            TapService s = inst;
            if (s == null) return false;
            Path p = new Path();
            p.moveTo(x1, y1);
            p.lineTo(x2, y2);
            return s.gesture(p, durMs);
        }
    }
}
